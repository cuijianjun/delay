//3.接收
this.onmessage=function (ev){
  let oDiv=ev.data;

  oDiv.style.background='red';
};
