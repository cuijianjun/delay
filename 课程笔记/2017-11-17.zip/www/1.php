<?php
echo $_POST['a'];
?>
