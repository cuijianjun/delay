<?php
echo $_FILE['f1'];
?>
