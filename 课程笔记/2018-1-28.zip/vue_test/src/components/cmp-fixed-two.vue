<template lang="html">
  <div class="fixed-two">
    <a href="#" class="code">
      <div>
        <span>下载app</span>
        <div class="code-img">
          <img src="/static/img/qrcode.png" alt="二维码" />
        </div>
        <span>扫一扫</span>
      </div>
    </a>
  </div>
</template>

<script>
export default {
  name: 'cmpFixedTwo'
}
</script>

<style lang="css">
</style>
