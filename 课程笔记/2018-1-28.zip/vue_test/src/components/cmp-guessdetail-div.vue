<template lang="html">
  <div class="guessdetail-div">
    <img src="/static/img/guess1.jpg" alt="猜你喜欢" />
    <p>房山-金樾和著</p>
    <p>38994元/㎡</p>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
