const path=require('path');

//console.log(path.resolve('/usr/root/', './aaa', '../../blue/bbb'));   //"/usr/blue/bbb"

//console.log(path.resolve(__dirname, 'src/1.js'));
console.log(`${__dirname}/src/1.js`);
