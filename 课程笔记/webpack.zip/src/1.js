$(function (){
  $('.box').click(function (){
    $('.box').css('background', 'red');
  });
});
