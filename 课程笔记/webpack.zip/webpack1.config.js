module.exports={
  entry: `${__dirname}/src/2.js`,
  output: {
    filename: '2.bundle.js',
    path: `${__dirname}/dist/`      //绝对：__dirname
  }
};
