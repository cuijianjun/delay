const util=require('util');

let res=util.isDeepStrictEqual('abc', 'abc');

console.log(res);
