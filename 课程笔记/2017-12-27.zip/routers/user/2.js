const router=require('../../libs/router');

let users={};

router.on('/forgot_pass', (req, res)=>{

});
router.on('/chg_face', (req, res)=>{
});
