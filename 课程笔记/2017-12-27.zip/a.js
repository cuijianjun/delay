const mod_b=require('./b');
const mod_c=require('./c');

console.log(mod_b.mod_c==mod_c);
