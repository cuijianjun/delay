const mod_c=require('./c');

exports.mod_c=mod_c;
