module.exports={
  //Database
  DB_HOST: 'localhost',
  DB_PORT: 3309,
  DB_USER: 'root',
  DB_PASS: '',
  DB_NAME: 'eleme',

  //
  PORT:    8080
};
