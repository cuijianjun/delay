const common=require('./libs/common');

console.log(common.md5('654321'));
