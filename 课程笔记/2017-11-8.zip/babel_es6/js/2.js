import m1 from "./mod/m1.js"

alert(m1.a);
