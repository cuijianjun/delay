let b=12;

export {b};
