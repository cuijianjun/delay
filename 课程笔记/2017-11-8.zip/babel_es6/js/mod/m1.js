let a=12;

export {a};
