const nmath=require('nmath');

console.log(nmath.divide(12, 66));
