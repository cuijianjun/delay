exports.a=12;
