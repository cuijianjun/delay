let mod2=require('2');
let mod3=require('3');

console.log(mod2.a+mod3.b);
