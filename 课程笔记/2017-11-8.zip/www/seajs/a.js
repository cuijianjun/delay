define(function (require, exports, module){
  exports.num1=12;
});
