let re=/\d+/g;
let str='asf4534fsdt 46456tesrdgs56456456 erfg5546';

console.log(str.match(re));
