let oDate=new Date();

console.log(oDate.getFullYear());
