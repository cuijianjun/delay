<template lang="html">
  <div class="all2-div">
    <div class="loginmenu-div">
      <div class="menu" style="line-height: 44px;padding-left: 20px;">
        <img src="/static/img/anjuke.png" style="margin-top: 10px;" />
        <a href="#">首 页</a><span class="line">|</span>
        <a href="#">新 房</a><span class="line">|</span>
        <a href="#">二手房</a><span class="line">|</span>
        <a href="#">租 房</a><span class="line">|</span>
        <a href="#">商铺写字楼</a><span class="line">|</span>
        <a href="#">海外地产</a><span class="line">|</span>
        <a href="#">楼 讯</a><span class="line">|</span>
        <a href="#">房 价</a><span class="line">|</span>
        <a href="#">问 答</a>
      </div>
      <div class="login">
        <a href="#">客户登录</a><span class="triangle-span" style="top:0;"></span><span class="line">|</span>
        <a href="#"><a class="user-icon" href="#"></a>用户登录</a>
        <a href="#">注册</a><span class="line">|</span>
        <a href="#"><a class="collect-icon" href="#"></a>收藏夹</a>
      </div>
    </div>
    <div class="sitesearch-div">
      <div class="item-div">
        <a href="#">北京安居客</a><span>></span>
        <a href="#">北京楼盘</a><span>></span>
        <a href="#">房山楼盘</a><span>></span>
        <a href="#">良乡楼盘</a><span>></span>
        <a href="#">金樾和著</a>
      </div>
      <form action="#" style="float:right;">
        <input class="searchtext" type="text" value="请输入楼盘名称、地址或房源特征" placeholder="请输入楼盘名称、地址或房源特征"/>
        <input type="button" class="searchbutton" value="搜 索" />
      </form>
    </div>
    <div class="lead-div">
      <div class="leadcode-div">
        <img src="/static/img/qrcode2.png" alt="二维码" width="60px" height="60px"/>
        <p>分享到微信</p>
      </div>
      <div class="leadtitle-div">
        <div class="leadtitlebig-div">金樾和著</div> <div class="sale-div">待售</div>
      </div>
      <div class="tag-div">
        <div class="tagleft-div">
        <span>轨交房</span>
        <span>医院</span>
        <span>商场</span>
        <span>大型超市</span>
        </div>
        <div class="phone-div">
          免费咨询：400 026 1357
        </div>
      </div>
    </div>
    <div class="add2-div">
      <img src="/static/img/add2.jpg" alt="广告" />
    </div>
    <div class="devide-div" style="margin-top: 0px;">
      <ul>
        <li>新盘</li>
        <li>楼讯</li>
        <li>热门活动</li>
        <li>看房团</li>
        <li>房源</li>
        <li>商业地产<span class="new-span"></span></li>
        <li>海外地产</li>
        <li>贷款</li>
        <li>品牌专区</li>
      </ul>
    </div>

    <div class="contain-div">
      <div class="contain-pic">
        <img src="/static/img/containpic.jpg" alt="房图" />
        <div class="snav-div">
          <img src="/static/img/change.jpg" alt="房图变换" />
          <img src="/static/img/change.jpg" alt="房图变换" />
          <img src="/static/img/change.jpg" alt="房图变换" />
          <img src="/static/img/change.jpg" alt="房图变换" />
          <img src="/static/img/change.jpg" alt="房图变换" />
        </div>

      </div>
      <div class="basicdetail-div">
          <div class="basicprice-div">参考价格  住宅<span style="font-size: 30px;font-size: 30px;vertical-align: -2px;color: #f60;margin: 0 5px;">{{houseData.ave_price}}</span> 元/㎡  </div>
          <div class="basicprice-div">楼盘户型  {{houseData.property_types}} </div>
          <div class="basicprice-div">楼盘地址  [ {{houseData.position_main}} ] {{houseData.position_second}}</div>
          <div class="blankgreen-div"><a href="#"></a><span>{{houseData.tel}}</span></div>
          <div class="basicprice-div">最新开盘   预计12月开盘 </div>
          <div class="basicprice-div">交房时间   2019年06月30日</div>
          <div class="basicprice-div">建筑类型  小高层、高层 </div>
      </div>
    </div>
    <div class="newactive-div">
      <h3>最新活动</h3>
      <div class="activecontent-div">
        <div class="activeleftpic-div">
          <img src="/static/img/active.jpg" alt="" />

        </div>
        <div class="activeinfo-div">
            <p class="loupan-div">楼盘活动：</p>
            <p class="shuliang-div">四雄布局京西南  数量有限 抢先报名</p>
            <p class="time-div">报名倒计时： 12天 12时 47分 06秒 参与人数：230人</p>
        </div>
      </div>
    </div>
    <div class="mianfei-div">
      <div class="mianfeicontent-div">
        <span class="kan-span"></span>
        <div class="actitem-div">
          <h4>免费专车 随时看房 HOT</h4>
          <div class="xiaoche-div">一对一小车接送 来回无忧 立享优惠</div>
        </div>
        <div class="join-div">63人已参加</div>
        <a href="#">约车看房</a>
      </div>
    </div>
    <div class="clearfix-div">
      <div class="zixun-div">
        <div class="clearfixtitle-div">
          <h3>
            动态资讯
          </h3>
        </div>
        <div class="mod">
          <div class="innermod-div">
            <div class="innertitle-div" style="margin-bottom: 14px;border-bottom: 1px dashed #e6e6e6;"><span class="dongtai-span">动态</span>金樾和著项目预计推出3-4居户型<span style="    font-size: 14px;color: #999;float: right;">2017-12-11 17:54:00</span><p>2017年12月11日讯：金樾和著项目预计在2017年12月开盘，预计主要推售户型为89㎡多功能三居、127㎡全家庭四居，预计均价38994元/㎡，位于房山区良乡镇中心。更多详情可咨询售</p></div>
          </div>
          <div class="innermod-div">
            <div class="innertitle-div"><span class="dongtai-span">动态</span>金樾和著项目预计推出3-4居户型<span style="    font-size: 14px;color: #999;float: right;">2017-12-11 17:54:00</span></div>
          </div>
        </div>
      </div>
      <div class="dingyue-div">
        <div class="clearfixtitle-div">
          <h3>
            订阅信息<span>（我们将为您保密个人信息）</span>
          </h3>
        </div>
        <div class="dingyuecontent-div">
          <div class="dingyueinner-div">
            <ul>
              <li><input type="checkbox" /><span>变价通知</span></li>
              <li><input type="checkbox" /><span>变价通知</span></li>
              <li style="width: 88px;"><input type="checkbox"/><span>变价通知</span></li>
              <li><input type="checkbox" checked/><span>变价通知</span></li>
              <li><input type="checkbox" /><span>变价通知</span></li>
            </ul>
            <a href="#">立即订阅</a>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix-div"></div>
    <div class="huxing-div">
      <div class="huxingtitle-div">
        <h3>楼盘户型</h3>
      </div>
      <div class="housetype-div">
        <ul>
          <li>
            <img src="/static/img/huxing1.jpg" alt="" />
            <div class="huxing-content">天悦户型 4室2厅2卫 待售主推
            建筑面积：约127.00m²</div>
          </li>
          <li>
            <img src="/static/img/huxing2.jpg" alt="" />
            <div class="huxing-content">景轩户型 3室2厅1卫 待售
            建筑面积：约89.00m²</div>
          </li>
        </ul>
      </div>
    </div>
    <div class="guwen-div">
      <div class="main-title">
        <h3>金牌置业顾问</h3>
      </div>
      <div class="guwen-content">
        <ul>
          <li>
            <img src="/static/img/teacher1.jpg" alt="老师" />
            <div class="teachername-div">
              <div class="teachernameleft-div">靳艳艳
                <a href="#" class="yuyue-div">预约</a>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="userclear-div">
      <div class="userleftclear-div">
        <div class="main-title">
          <h3>用户点评</h3>
        </div>
        <div class="userleftcontent-div">
          <ul class="review-ul">
            <li>现在觉得买房好绝望，政府各种调控也没见房价下来啊。这房就是大开发商，估计价格更不会低了。过千万不是梦吧，还是周边多看...</li>
            <li>最近一直在看房子，现在觉得这项目真的还是挺好的。就是不知道什么时候能开盘，而且我觉得看盘也不会低，现在就是密切关注...</li>
          </ul>
          <div class="publishmod-div">
            <p style="text-align: right;">
              <span>需要登录才能点评哦！</span>
              <a href="#">写点评赢积分，我要点评</a>
            </p>
          </div>
        </div>
      </div>
      <div class="comment-div">
        <div class="main-title">
          <h3>点评达人</h3>
        </div>
        <div class="commentcontent-div">
          <ul>
            <li>
              <div class="line-dashed">
              </div>
              <div class="yeild-div">
                <div class="commentinfo-div">
                  <img src="/static/img/head.jpg" alt="头像" />
                  <p>民间房评人好房好人</p>
                  <p>点评10个楼盘</p>
                </div>
                <p class="truecomment-div">你以为的就是你以为的吗</p>
              </div>
            </li>
            <li>
              <div class="line-dashed">
              </div>
              <div class="yeild-div">
                <div class="commentinfo-div">
                  <img src="/static/img/head.jpg" alt="头像" />
                  <p>民间房评人好房好人</p>
                  <p>点评10个楼盘</p>
                </div>
                <p class="truecomment-div">你以为的就是你以为的吗</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="map-div">
      <div class="main-title">
        <h3>
          周边配套
        </h3>
      </div>
      <div class="mapcontent-div">
        <img src="/static/img/map.png" alt="地图" />
        <div class="life-div">
          <ul class="life-ul">
            <li><a href="#" style="color:white;background: #62ab00;">交通</a></li>
            <li><a href="#">商业</a></li>
            <li><a href="#">教育</a></li>
            <li><a href="#">医院</a></li>
          </ul>
          <div class="lifelist-div">
            <p style="color:#999;">2公里内的交通设施</p>
            <p>13个公交站</p>
            <ul>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
              <li><a href="#"></a><p class="zhan-p">邢家务东站 <span class="lu-span">（房48路）</span></p><span class="mi-span">405米</span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="yuegong-div" style="overflow: hidden;">
      <div class="main-title">
        <h3>
          产品月供
        </h3>
        <div class="yuegongcontent-div">
          <div class="yuegongleft-div" style="font-size: 20px;line-height: 20px;margin: 20px 0;">
            计算条件
            <div></div>
          </div>
        </div>
      </div>
    </div>
    <div class="guesshouselike-div">
      <div class="main-title">
        <h3>猜你喜欢</h3>
      </div>
      <div class="guesscontent-div">
        <ul>
          <li>
            <img src="/static/img/housepic.jpg" alt="#" />
            <a href="#">永清-森林新都孔雀城</a>
            <p>15500元/㎡</p>
          </li>
          <li>
            <img src="/static/img/housepic.jpg" alt="#" />
            <a href="#">永清-森林新都孔雀城</a>
            <p>15500元/㎡</p>
          </li>
          <li>
            <img src="/static/img/housepic.jpg" alt="#" />
            <a href="#">永清-森林新都孔雀城</a>
            <p>15500元/㎡</p>
          </li>
          <li>
            <img src="/static/img/housepic.jpg" alt="#" />
            <a href="#">永清-森林新都孔雀城</a>
            <p>15500元/㎡</p>
          </li>
          <li>
            <img src="/static/img/housepic.jpg" alt="#" />
            <a href="#">永清-森林新都孔雀城</a>
            <p>15500元/㎡</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="recomenned-div">
      <div class="listitem-div">
        <div class="main-title">
          <h3>附近的楼盘</h3>
        </div>
        <div class="listcontent-div">
          <ul>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
          </ul>
        </div>
      </div>
      <div class="listitem-div">
        <div class="main-title">
          <h3>附近的楼盘</h3>
        </div>
        <div class="listcontent-div">
          <ul>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
          </ul>
        </div>
      </div>
      <div class="listitem-div" style="padding-right: 0;">
        <div class="main-title">
          <h3>附近的楼盘</h3>
        </div>
        <div class="listcontent-div">
          <ul>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
            <li><a href="#">恒大国际广场 </a> <span class="area">房山 </span> <span class="price"><span style="color:#f60;">30000</span>元/㎡起</span></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="housead-div">
      <img src="/static/img/xyd-banner.jpg" alt="" />
    </div>
    <div class="housebuttom-div">
      <div class="main-title">
          <h3>金樾和著</h3>
      </div>
      <div class="infoarea-div">
        <div class="info-item">楼盘别名：金樾和著</div>
        <div class="info-item">参考价格：38994元/㎡  地址： [ 房山  良乡 ] 良乡镇</div>
        <div class="info-item">金樾和著楼盘频道，提供北京金樾和著 房价，楼盘户型，楼盘产权年限，物业费，开发商，售楼电话，绿化率，周边配套，商场，超市，学校，医院，银行，周边地图交通等全方位楼盘信息，金樾和著价格。手机版： 金樾和著 北京开发商 北京物业公司 北京热门楼盘 北京新房网</div>
        <div class="info-item">推荐楼盘：<a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a></div>
        <div class="info-item">推荐楼盘：<a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a></div>
        <div class="info-item">推荐楼盘：<a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a></div>
        <div class="info-item">推荐楼盘：<a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a></div>
        <div class="info-item" style="border: 0px;">推荐楼盘：<a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a><a href="#">燕郊孔雀城</a></div>
      </div>
    </div>
    <div class="avoid-div" style="margin-top: 30px;">免责声明：本站旨在为广大用户提供更多信息服务，不声明或保证所提供信息的准确性和完整性。页面所载内容及数据仅供用户参考和借鉴，最终以开发商实际公示为准，用户因参照本站信息进行相关交易所造成的任何后果与本站无关。如楼盘信息有误，您可以投诉或拨打举报电话：400-620-6688
    </div>
    <div class="intro-div">
      <ul>
        <li>关于安居客<span>|</span></li>
        <li>联系我们<span>|</span></li>
        <li>用户协议<span>|</span></li>
        <li>友情链接<span>|</span></li>
        <li>网站地图<span>|</span></li>
        <li>其他城市<span>|</span></li>
        <li>最新房源<span>|</span></li>
        <li>最新问答<span>|</span></li>
        <li>房贷计算器<span>|</span></li>
        <li>放心搜<span>|</span></li>
        <li>订阅退订<span>|</span></li>
      </ul>
      <br />
      <span style="text-align: center;">客服热线/虚假信息举报：400-620-6688邮箱：service@58ganji.comCopyright © 2007-2017 www.anjuke.com All Rights Reserved ICP号：沪 B2-20090008
      </span>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    let dataBus = {
      houseData: {}
    }

    this.$a.get(`http://localhost:8081/api/house/${this.$route.params.id}`).then(res => {
      let json = res.data

      if (json.err) {
        alert('错了')
      } else {
        dataBus.houseData = json.data
      }
    }, err => {
      alert('错了')
      console.log('错了', err)
    })

    return dataBus
  }
}
</script>

<style lang="css">
</style>
