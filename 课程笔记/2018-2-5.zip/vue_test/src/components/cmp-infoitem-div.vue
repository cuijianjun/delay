<template lang="html">
  <div class="infoitem2-div">
    <label>推荐楼盘：</label>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
    <a href="#">雄安新区</a>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
