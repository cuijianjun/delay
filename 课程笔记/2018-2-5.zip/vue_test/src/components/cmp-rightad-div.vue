<template lang="html">
  <div class="rightadd-div">
    <div class="add-boxdiv">
    <img src="/static/img/addright.jpg" alt="右侧广告" />
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
