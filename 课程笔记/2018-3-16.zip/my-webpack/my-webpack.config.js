module.exports={
  entry: {
    app: './1.js'
  },
  output: {
    filename: 'dest/bundle.js'
  }
};
