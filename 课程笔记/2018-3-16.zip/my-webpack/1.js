import mod1 from 'libs/mod1'
const mod2=require('libs/mod2');

console.log(mod1.a+mod2.b);
