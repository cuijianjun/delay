let arr:Array<number|string>;

arr=[12,5,8,99,'abc'];

console.log(arr);
