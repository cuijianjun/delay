function sum(a, b) {
    return a + b + '7';
    //return 'abc';
}
alert(sum(12, 5));
