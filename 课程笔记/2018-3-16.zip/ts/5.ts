function show(age: number, name: string):void{
  alert(`我叫${name}，我今年${age}岁`);

  //return 12;
}

show(18, 'blue');
