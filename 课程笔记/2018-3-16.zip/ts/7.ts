let a:any=12;

let b:string=(<string>a);
