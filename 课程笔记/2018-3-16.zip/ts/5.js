function show(age, name) {
    alert("\u6211\u53EB" + name + "\uFF0C\u6211\u4ECA\u5E74" + age + "\u5C81");
    //return 12;
    return;
}
show(18, 'blue');
