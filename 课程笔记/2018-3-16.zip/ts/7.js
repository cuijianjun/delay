var a = 12;
var b = a;
