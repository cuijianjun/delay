function a():never{
  while(true){}
}

a();
