function sum(a:number, b:number):number{
  return a+b+'7';
  //return 'abc';
}

alert(sum(12, 5));
