var a;
var b = 5;
//a=12;
a = '12bsdfas';
alert(a + b);
