let a:number=0;
let b=5;

//a=12;
a='12bsdfas';

alert(a+b);
