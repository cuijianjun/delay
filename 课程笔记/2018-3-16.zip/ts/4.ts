enum Gender{male, female};

let gen1:Gender=Gender.male;

if(gen1==Gender.male){
  console.log('男的');
}else{
  console.log('女的');
}
