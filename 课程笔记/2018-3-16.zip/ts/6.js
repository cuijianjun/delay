function a() {
    while (true) { }
}
a();
