const common=require('./libs/common');

console.log(common.uuid());
console.log(common.uuid());
console.log(common.uuid());
console.log(common.uuid());
