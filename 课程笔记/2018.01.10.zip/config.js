module.exports={
  //端口
  port: 8080,

  //数据库
  mysql_host: 'localhost',
  mysql_port: 3309,
  mysql_user: 'root',
  mysql_password: '',
  mysql_dbname: 'an_ju_ke',

  //超级管理员配置
  root_username: 'blue',
  root_password: 'e10adc3949ba59abbe56e057f20f883e',
};
