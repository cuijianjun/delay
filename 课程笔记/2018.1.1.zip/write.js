const fs=require('fs');

fs.appendFile('a.txt', 'sdfasdfdf', ()=>{});
