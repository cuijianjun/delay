const path=require('path');

//console.log(path);
let str=path.resolve('./abc/ddd/1.txt');

console.log(str);
